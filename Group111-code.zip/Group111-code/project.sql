-- 1. 车型汇总表
CREATE TABLE car_models (
    model_id INT AUTO_INCREMENT PRIMARY KEY,  -- 车型ID
    series_name VARCHAR(100) NOT NULL,        -- 系列名称
    model_name VARCHAR(100) NOT NULL,         -- 车型名称
    car_level VARCHAR(50),                    -- 汽车级别（如“A级车”、“B级车”）
    year INT NOT NULL                        -- 车型年份
);

-- 索引：按系列和级别排序
CREATE INDEX idx_series_level ON car_models(series_name, car_level);

-- 2. 车型性能参数表
CREATE TABLE car_performance (
    performance_id INT AUTO_INCREMENT PRIMARY KEY,  -- 性能参数ID
    model_id INT NOT NULL,                          -- 车型ID（外键）
    engine_type VARCHAR(50),                        -- 发动机类型（如“汽油”）
    horsepower INT,                                 -- 马力
    torque INT,                                     -- 扭矩
    acceleration VARCHAR(50),                       -- 加速性能（如“0-100km/h 8秒”）
    max_speed INT,                                  -- 最高车速
    fuel_efficiency DECIMAL(5, 2),                  -- 油耗
    weight INT,                                     -- 车辆重量
    dimensions VARCHAR(50),                         -- 车身尺寸
    FOREIGN KEY (model_id) REFERENCES car_models(model_id) ON DELETE CASCADE ON UPDATE CASCADE --与车型表级联增删
);

-- 索引：按车型ID优化查询
CREATE INDEX idx_model_id_performance ON car_performance(model_id);

-- 3. 车辆配置表
CREATE TABLE car_configurations (
    config_id INT AUTO_INCREMENT PRIMARY KEY,  -- 配置ID
    model_id INT NOT NULL,                     -- 车型ID（外键）
    configuration_name VARCHAR(100),           -- 配置名称（如“标准版”、“豪华版”）
    price DECIMAL(10, 2),                      -- 配置价格
    features TEXT,                             -- 配置特性（如“天窗、座椅加热”）
    FOREIGN KEY (model_id) REFERENCES car_models(model_id) ON DELETE CASCADE ON UPDATE CASCADE --与车型表级联增删
);

-- 索引：按车型ID优化查询
CREATE INDEX idx_model_id_config ON car_configurations(model_id);

-- 4. 客户表
CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,  -- 客户ID
    name VARCHAR(100) NOT NULL,                  -- 客户姓名
    phone VARCHAR(15),                           -- 客户电话
    email VARCHAR(100),                          -- 客户邮箱
    address TEXT,                                -- 客户地址
    purchase_date DATE,                          -- 购车日期
    model_id INT DEFAULT 'sp',                 -- 客户购买的车型ID，(默认值为'sp'(stop_production))
    config_id INT DEFAULT 'sp',                -- 客户选择的配置ID，(默认值为'sp'(stop_production))
    price DECIMAL(10, 2),                        -- 购车价格
    FOREIGN KEY (model_id) REFERENCES car_models(model_id) ON DELETE SET DEFAULT, --车型表删除后填充默认值
    FOREIGN KEY (config_id) REFERENCES car_configurations(config_id) ON DELETE SET DEFAULT --配置表删除后填充默认值
);

-- 索引：按客户购买的车型ID和配置ID优化查询
CREATE INDEX idx_model_id_customer ON customers(model_id);
CREATE INDEX idx_config_id_customer ON customers(config_id);

-- 5. 零件信息表
CREATE TABLE car_parts (
    part_id INT AUTO_INCREMENT PRIMARY KEY,   -- 零件ID
    part_name VARCHAR(100) NOT NULL,           -- 零件名称
    part_number VARCHAR(50) UNIQUE,            -- 零件编号
    part_type VARCHAR(50),                     -- 零件类型（如“发动机部件”）
    price DECIMAL(10, 2)                      -- 零件价格
);

-- 索引：按零件编号优化查询
CREATE INDEX idx_part_number ON car_parts(part_number);

-- 6. 供应商信息表
CREATE TABLE suppliers (
    supplier_id INT AUTO_INCREMENT PRIMARY KEY,   -- 供应商ID
    name VARCHAR(100) NOT NULL,                   -- 供应商名称
    contact_person VARCHAR(100),                  -- 联系人
    contact_phone VARCHAR(15),                    -- 联系电话
    contact_email VARCHAR(100),                   -- 联系邮箱
    address TEXT                                 -- 地址
);

-- 索引：按供应商名称优化查询
CREATE INDEX idx_supplier_name ON suppliers(name);

-- 7. 零件供给关系表
CREATE TABLE parts_supply (
    supply_id INT AUTO_INCREMENT PRIMARY KEY,  -- 供给ID
    part_id INT DEFAULT 'su',                      -- 零件ID（外键）,(默认值为'su'(stop_using))
    model_id INT DEFAULT 'sp',                     -- 适用的车型ID（外键）,(默认值为'sp'(stop_production))
    supplier_id INT DEFAULT 'ss',                  -- 供应商ID（外键）,(默认值为'ss'(stop_supply))
    supply_date DATE,                          -- 供货日期
    quantity INT,                              -- 供货数量
    FOREIGN KEY (part_id) REFERENCES car_parts(part_id) ON DELETE SET DEFAULT, --零件表删除后填充默认值
    FOREIGN KEY (model_id) REFERENCES car_models(model_id) ON DELETE SET DEFAULT, --车型表删除后填充默认值
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id) ON DELETE SET DEFAULT --供应商表删除后填充默认值
);

-- 索引：按零件ID、车型ID、供应商ID优化查询
CREATE INDEX idx_part_model_supplier ON parts_supply(part_id, model_id, supplier_id);

-- 8. 客户维修记录表
CREATE TABLE repair_records (
    repair_id INT AUTO_INCREMENT PRIMARY KEY,    -- 维修记录ID
    customer_id INT NOT NULL,                    -- 客户ID（外键）
    model_id INT DEFAULT 'sp',                       -- 维修的车型ID（外键）
    old_part_id INT DEFAULT 'su',                             -- 旧零件ID（外键）
    new_part_id INT DEFAULT 'su',                             -- 新零件ID（外键）
    purchased_parts TEXT,                        -- 客户额外购买的零件（以JSON或TEXT存储零件ID）
    repair_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- 维修日期
    total_cost DECIMAL(10, 2),                   -- 维修总费用
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE ON UPDATE CASCADE, --与客户表级联增删
    FOREIGN KEY (model_id) REFERENCES car_models(model_id) ON DELETE SET DEFAULT, --车型表删除后填充默认值
    FOREIGN KEY (old_part_id) REFERENCES car_parts(part_id) ON DELETE SET DEFAULT, --零件表删除后填充默认值
    FOREIGN KEY (new_part_id) REFERENCES car_parts(part_id) ON DELETE SET DEFAULT, --零件表删除后填充默认值
    CHECK (old_part_id = 'su' OR old_part_id > 0), -- 如果维修的零件已停用则输入'su'，否则应在有效范围
    CHECK (new_part_id = 'su' OR new_part_id > 0), -- 如果维修的零件已停用则输入'su'，否则应在有效范围
    CHECK (model_id = 'sp' OR model_id > 0)  -- 如果维修的车型已停产则输入'sp'，否则应在有效范围
);


-- 索引：按客户ID和车型ID优化查询
CREATE INDEX idx_customer_id_repair ON repair_records(customer_id);
CREATE INDEX idx_model_id_repair ON repair_records(model_id);

-- 9. 性能优化和索引总结

-- 索引：创建用于常见查询字段的索引
CREATE INDEX idx_car_model_name ON car_models(model_name);
CREATE INDEX idx_car_series ON car_models(series_name);
CREATE INDEX idx_car_level ON car_models(car_level);

