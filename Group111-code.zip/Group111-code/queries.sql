
-- 增添 
-- 1. 车型汇总表 (car_models)
INSERT INTO car_models (model_id, series_name, model_name, car_level, year)
VALUES (6, 'Tesla Roadster', 'Tesla Roadster', 'Class A', 2024);


-- 2. 车型性能参数表 (car_performance)
INSERT INTO car_performance (performance_id, model_id, engine_type, horsepower, torque, acceleration, max_speed, fuel_efficiency, weight, dimensions)
VALUES (10005, 6, 'Electric', 1000, 1200, '0-100km/h in 1.9s', 420, 7.0, 2000, '4200mm x 2000mm x 1150mm');


-- 3. 车辆配置表 (car_configurations)
INSERT INTO car_configurations (config_id, model_id, configuration_name, price, features)
VALUES (600, 6, 'Base Model', 200000, 'Full Self-Driving, Premium Sound System, Removable Top');


-- 4. 客户表 (customers)
INSERT INTO customers (customer_id, name, phone, email, address, purchase_date, model_id, config_id, price)
VALUES (678910, 'Dana White', '13678901234', 'dana@example.com', 'Downtown, Los Angeles', '2024-07-15', 6, 600, 200000);


-- 5. 零件信息表 (car_parts)
INSERT INTO car_parts (part_id, part_name, part_number, part_type, price)
VALUES (106, 'Roadster Battery', 'BAT12345', 'Battery Pack', 35000.00);


-- 6. 供应商信息表 (suppliers)
INSERT INTO suppliers (supplier_id, name, contact_person, contact_phone, contact_email, address)
VALUES (45, 'Supplier D', 'Emily Zhou', '13876543210', 'emily@supplierD.com', 'Central District, Shenzhen');


-- 7. 零件供给关系表 (parts_supply)
INSERT INTO parts_supply (supply_id, part_id, model_id, supplier_id, supply_date, quantity)
VALUES (6006, 106, 6, 45, '2024-08-01', 20);


-- 8. 客户维修记录表 (repair_records)
INSERT INTO repair_records (repair_id, customer_id, model_id, old_part_id, new_part_id, purchased_parts, repair_date, total_cost)
VALUES (133, 678910, 6, 102, 106, '[106]', '2024-08-20 11:00:00', 40000.00);


-- 删除
-- 1. 特定车型汇总表 (car_models)
DELETE FROM car_models WHERE model_id = 6;


-- 清空整表
TRUNCATE TABLE car_models;

-- 2. 特定车型性能参数表 (car_performance)
DELETE FROM car_performance WHERE performance_id = <指定的performance_id>;

-- 清空整表
TRUNCATE TABLE car_performance;

-- 3. 特定车辆配置表 (car_configurations)
DELETE FROM car_configurations WHERE config_id = <指定的config_id>;

-- 清空整表
TRUNCATE TABLE car_configurations;

-- 4. 特定客户表 (customers)
DELETE FROM customers WHERE customer_id = <指定的customer_id>;

-- 清空整表
TRUNCATE TABLE customers;

-- 5. 特定零件信息表 (car_parts)
DELETE FROM car_parts WHERE part_id = <指定的part_id>;

-- 清空整表
TRUNCATE TABLE car_parts;

-- 6. 特定供应商信息表 (suppliers)
DELETE FROM suppliers WHERE supplier_id = <指定的supplier_id>;

-- 清空整表
TRUNCATE TABLE suppliers;

-- 7. 特定零件供给关系表 (parts_supply)
DELETE FROM parts_supply WHERE supply_id = <指定的supply_id>;

-- 清空整表
TRUNCATE TABLE parts_supply;

-- 8. 特定客户维修记录表 (repair_records)
DELETE FROM repair_records WHERE repair_id = <指定的repair_id>;

-- 清空整表
TRUNCATE TABLE repair_records;


-- 修改
-- 1. 车型汇总表 (car_models)
UPDATE car_models 
SET series_name = 'Tesla Roadster', 
    model_name = 'Tesla Roadster', 
    car_level = 'Class A', 
    year = 2024
WHERE model_id = 5;


-- 2. 车型性能参数表 (car_performance)
UPDATE car_performance 
SET engine_type = '<发动机类型>', 
    horsepower = <马力>, 
    torque = <扭矩>, 
    acceleration = '<加速性能>', 
    max_speed = <最高车速>, 
    fuel_efficiency = <油耗>, 
    weight = <车辆重量>, 
    dimensions = '<车身尺寸>'
WHERE performance_id = <指定的performance_id>;

-- 3. 车辆配置表 (car_configurations)
UPDATE car_configurations 
SET configuration_name = '<配置名称>', 
    price = <配置价格>, 
    features = '<配置特性>'
WHERE config_id = <指定的config_id>;

-- 4. 客户表 (customers)
UPDATE customers 
SET name = '<客户姓名>', 
    phone = '<客户电话>', 
    email = '<客户邮箱>', 
    address = '<客户地址>', 
    purchase_date = '<购车日期>', 
    model_id = <model_id>, 
    config_id = <config_id>, 
    price = <购车价格>
WHERE customer_id = <指定的customer_id>;

-- 5. 零件信息表 (car_parts)
UPDATE car_parts 
SET part_name = '<零件名称>', 
    part_number = '<零件编号>', 
    part_type = '<零件类型>', 
    price = <零件价格>
WHERE part_id = <指定的part_id>;

-- 6. 供应商信息表 (suppliers)
UPDATE suppliers 
SET name = '<供应商名称>', 
    contact_person = '<联系人>', 
    contact_phone = '<联系电话>', 
    contact_email = '<联系邮箱>', 
    address = '<地址>'
WHERE supplier_id = <指定的supplier_id>;

-- 7. 零件供给关系表 (parts_supply)
UPDATE parts_supply 
SET part_id = <part_id>, 
    model_id = <model_id>, 
    supplier_id = <supplier_id>, 
    supply_date = '<供货日期>', 
    quantity = <供货数量>
WHERE supply_id = <指定的supply_id>;

-- 8. 客户维修记录表 (repair_records)
UPDATE repair_records 
SET customer_id = <customer_id>, 
    model_id = <model_id>, 
    old_part_id = <old_part_id>, 
    new_part_id = <new_part_id>, 
    purchased_parts = '<额外购买的零件>', 
    total_cost = <维修总费用>
WHERE repair_id = <指定的repair_id>;




-- 查询
-- 销量统计
SELECT 
    cm.model_id,
    cm.model_name, 
    COUNT(*) 
FROM 
    customers c
JOIN 
    car_models cm ON c.model_id = cm.model_id
GROUP BY 
    cm.model_id, cm.model_name;
*

--售价统计 
SELECT 
    cm.model_name, 
    SUM(c.price) AS total_price
FROM 
    customers c
JOIN 
    car_models cm ON c.model_id = cm.model_id
GROUP BY 
    cm.model_name; 



-- 车系销量统计
SELECT 
    cm.series_name,
    COUNT(*) AS customer_count,
    SUM(c.price) AS total_price
FROM 
    customers c
JOIN 
    car_models cm ON c.model_id = cm.model_id
JOIN 
    car_configurations cc ON c.config_id = cc.config_id
WHERE 
    cm.series_name = 'Tesla Model S'
GROUP BY 
    cm.series_name;

	

-- 查询零件库存
SELECT 
    p.part_id,
    p.part_name,
    SUM(ps.quantity) AS current_stock_level
FROM 
    car_parts p,
	parts_supply ps
WHERE
	p.part_id = ps.part_id
GROUP BY 
    p.part_id, p.part_name;



-- 查询特定车系下的所有车型及其对应的性能参数和配置选项
SELECT 
    cm.model_name, 
    cm.car_level,
    cm.year,
    cp.engine_type,
    cp.horsepower,
    cp.torque,
    cp.acceleration,
    cp.max_speed,
    cp.fuel_efficiency,
    cp.weight,
    cp.dimensions,
    cc.configuration_name,
    cc.price AS config_price,
    cc.features
FROM 
    car_models cm
JOIN 
    car_performance cp ON cm.model_id = cp.model_id
JOIN 
    car_configurations cc ON cm.model_id = cc.model_id
WHERE 
    cm.series_name = 'Tesla Model S'
ORDER BY 
    cm.model_name, 
    cc.configuration_name;


-- 查询客户维修历史
SELECT 
    c.customer_id,
    r.repair_id,
    c.name AS customer_name,
    cm.model_name,
    cp.part_name AS old_part_name,
    cp2.part_name AS new_part_name,
    r.total_cost,
    r.repair_date
FROM 
    repair_records r
JOIN 
    customers c ON r.customer_id = c.customer_id
JOIN 
    car_models cm ON r.model_id = cm.model_id
LEFT JOIN 
    car_parts cp ON r.old_part_id = cp.part_id
LEFT JOIN 
    car_parts cp2 ON r.new_part_id = cp2.part_id
WHERE 
    c.customer_id = 123456
ORDER BY 
    r.repair_date DESC;

	
-- 查询零件信息
SELECT 
    p.part_id,
    p.part_name,
    p.part_number,
    p.part_type,
    p.price AS part_price,
    cm.model_name,
    s.name AS supplier_name
FROM 
    car_parts p
JOIN 
    parts_supply ps ON p.part_id = ps.part_id
JOIN 
    car_models cm ON ps.model_id = cm.model_id
JOIN 
    suppliers s ON ps.supplier_id = s.supplier_id
WHERE 
    p.part_id = 101
	
