INSERT INTO car_models (model_id, series_name, model_name, car_level, year)
VALUES 
    (1, 'Tesla Model S', 'Tesla Model S Long Range', 'Class A', 2024),
    (2, 'Tesla Model 3', 'Tesla Model 3 Performance', 'Class B', 2023),
    (3, 'Tesla Model X', 'Tesla Model X Plaid', 'Class A', 2024),
    (4, 'Tesla Model Y', 'Tesla Model Y Long Range', 'Class C', 2024),
    (5, 'Tesla Cybertruck', 'Tesla Cybertruck Dual Motor', 'Class B', 2023);

INSERT INTO car_performance (performance_id, model_id, engine_type, horsepower, torque, acceleration, max_speed, fuel_efficiency, weight, dimensions)
VALUES
    (10000, 1, 'Electric', 670, 1050, '0-100km/h in 3.1s', 250, 15.5, 2100, '4970mm x 1964mm x 1445mm'),
    (10001, 2, 'Electric', 480, 639, '0-100km/h in 3.3s', 261, 14.3, 1847, '4694mm x 1849mm x 1443mm'),
    (10002, 3, 'Electric', 1020, 1400, '0-100km/h in 2.5s', 262, 17.2, 2441, '5036mm x 1999mm x 1684mm'),
    (10003, 4, 'Electric', 346, 527, '0-100km/h in 4.8s', 217, 16.9, 2003, '4751mm x 1921mm x 1624mm'),
    (10004, 5, 'Electric', 690, 832, '0-100km/h in 4.5s', 210, 18.1, 3400, '5885mm x 2027mm x 1905mm');

INSERT INTO car_configurations (config_id, model_id, configuration_name, price, features)
VALUES
    (100, 1, 'Full Self-Driving', 79900, 'Autopilot, Heated Seats, 17-inch Touchscreen, Long Range Battery'),
    (200, 2, 'Performance', 59900, 'Performance Upgrade, Ventilated Seats, 15-inch Touchscreen'),
    (300, 3, 'Plaid', 139900, 'Tri-Motor AWD, Advanced sound system, Falcon Wing Doors'),
    (400, 4, 'Long Range', 52900, 'Autopilot, Heated Rear Seats, 19-inch Wheels'),
    (500, 5, 'Dual Motor', 49900, 'Armor Glass, Autopilot, Massive Cargo Capacity');

INSERT INTO customers (customer_id, name, phone, email, address, purchase_date, model_id, config_id, price)
VALUES
    (123456, 'Alice Smith', '13912345678', 'alice@example.com', 'Chaoyang District, Beijing', '2024-03-15', 1, 100, 79900),
    (234567, 'Bob Johnson', '13823456789', 'bob@example.com', 'Pudong New Area, Shanghai', '2023-12-10', 2, 200, 59900),
    (456789, 'Charlie Brown', '13734567890', 'charlie@example.com', 'Tianhe District, Guangzhou', '2024-05-20', 3, 300, 139900);


INSERT INTO car_parts (part_id,part_name, part_number, part_type, price)
VALUES
    (101,'Engine', 'ENG1234', 'Engine Parts', 15000.00),
    (102,'Brake Pads', 'BRK5678', 'Brake System', 800.00),
    (103,'Seats', 'SEA9012', 'Interior', 1200.00),
    (104,'Tires', 'TIR3456', 'Wheels', 1000.00),
    (105,'Air Conditioning System', 'ACD7890', 'AC Parts', 2500.00);
	
INSERT INTO suppliers (supplier_id,name, contact_person, contact_phone, contact_email, address)
VALUES
    (11,'Supplier A', 'Li Hua', '13812345678', 'lihua@supplierA.com', 'Chaoyang District, Beijing'),
    (21,'Supplier B', 'Wang Wei', '13923456789', 'wangwei@supplierB.com', 'Pudong New Area, Shanghai'),
    (36,'Supplier C', 'Zhang Qiang', '13734567890', 'zhangqiang@supplierC.com', 'Tianhe District, Guangzhou');
	
INSERT INTO parts_supply (supply_id,part_id, model_id, supplier_id, supply_date, quantity)
VALUES
    (6001,101, 1, 11, '2024-03-10', 10),
    (6002,102, 2, 21, '2023-12-05', 50),
    (6003,103, 3, 36, '2024-06-01', 20),
    (6004,104, 4, 11, '2024-05-10', 15),
    (6005,105, 5, 21, '2023-11-22', 30);
	
INSERT INTO repair_records (repair_id, customer_id, model_id, old_part_id, new_part_id, purchased_parts, repair_date, total_cost)
VALUES
    (90, 123456, 1, 105, 102, '[3,4]', '2024-06-10 14:00:00', 8000.00),
    (87, 234567, 2, 102, 103, '[1,4]', '2024-01-20 10:00:00', 4000.00),
    (132, 456789, 3, 103, 104, '[2,5]', '2024-07-01 16:00:00', 6000.00);

