# New Energy Vehicle Database Management System (NEV-DBMS)

## Project Overview

The **New Energy Vehicle Database Management System (NEV-DBMS)** is a specialized database management system focusing on new energy vehicles (such as electric vehicles, hybrid vehicles, etc.). This project operates SQL queries through SQLite, aiming to provide an efficient and user-friendly platform for managing all information related to new energy vehicles. This includes, but is not limited to, car model summaries, performance parameters, vehicle configurations, customer information, parts information, supplier information, and repair records.



## Directory Structure

All operations are performed directly via SQL commands against the SQLite database. The structure of the project is primarily composed of SQL scripts and documentation files.

```
NEV-DBMS/
│
├── Group 111-docs.zip/         # Directory containing project documents
│   └── UCD.jpg					# Use Case Diagram
│   └── ERD.png					# Entity-Relationship Diagram
│   └── LDM.png					# Logical Data Model
│   └── data dictionary.xlsx	# Data Dictionary
│   └── README.md                # This README file
│
├── Group 111-code.zip/         # Directory containing SQL script files
│   ├── project.sql    			# SQL script for creating database tables
│   ├── insert.sql      		# SQL script for inserting initial data
│   └── queries.sql          	# Common SQL queries used for interacting with the database
│   ├── project.sqlite    			# SQLite database file
```



## Features

### 1. Car Models Table

Manages information about different models of new energy vehicles, including series name, model name, car level, and year.

### 2. Car Performance Table

Records detailed performance metrics for each car model, such as engine type, horsepower, torque, acceleration, max speed, fuel efficiency, weight, and dimensions.

### 3. Car Configurations Table

Lists available configurations for each car model, including configuration names, prices, and features.

### 4. Customers Table

Tracks customer information, including purchase date, selected car model and configuration, and the final price paid.

### 5. Car Parts Table

Maintains a catalog of car parts, including part name, part number, type, and price.

### 6. Suppliers Table

Holds information about suppliers, including contact details and addresses.

### 7. Parts Supply Table

Documents the supply relationship between parts and suppliers, recording supply dates and quantities.

### 8. Repair Records Table

Logs all repair activities, linking them to customers, their cars, and the parts involved in repairs, along with the total cost.



## Getting Started

### Prerequisites

- Ensure you have SQLite installed on your computer. You can download it from [SQLite's official website](https://www.sqlite.org/download.html).

### Setup

1. Navigate to the `Group 111-code.zip/` directory and create the SQLite database using the provided `project.sql` file.
2. Populate the database with initial data by executing the `insert.sql` script.
3. Use the `queries.sql` file to interact with the database as needed.

### Running Queries

To execute SQL queries, use any SQLite command-line tool or GUI client. For example, to run a query from the command line:

```bash
sqlite3 Group 111-code/project.sqlite
```

Then, within the SQLite prompt, you can run individual queries:

```mysql
SELECT * FROM car_models;
```



## Contributing

Contributions are welcome! If you find a bug or have a feature request, please open an issue. Pull requests are also welcomed for direct contributions to the project.